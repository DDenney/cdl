package http://hl7.org/fhir/us/cdl/ImplementationGuide/ig;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class DeviceCRN {

}
